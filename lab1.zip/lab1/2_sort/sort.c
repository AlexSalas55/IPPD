#include <time.h>
#include <stdlib.h>
#include <omp.h>
#include "sort.h"

#define NUM_THREADS 8
#define INT_MAX 2147483647
#include <string.h>

int sort(int *array, int n) {
    int i, j, tmp;

    for (i=1;i<n;i++) {  
        tmp = array[i];  
        for(j=i-1;j >= 0 && array[j] > tmp;j--) {  
            array[j+1] = array[j];  
        }  
        array[j+1] = tmp;  
    }
}

int sort_openmp(int *array, int n) {
    int *tmp_array = malloc(n * sizeof(int));
    int chunk_size = n / NUM_THREADS;
    int i, j, min_index, min_value;

    #pragma omp parallel num_threads(NUM_THREADS)
    {
        int tid = omp_get_thread_num();
        int start = tid * chunk_size;
        int end = (tid == NUM_THREADS - 1) ? n : start + chunk_size;

        sort(array + start, end - start);
        memcpy(tmp_array + start, array + start, (end - start) * sizeof(int));
    }

    int *head_i = malloc(NUM_THREADS * sizeof(int));
    for (i = 0; i < NUM_THREADS; i++) {
        head_i[i] = i * chunk_size;
    }

    for (i = 0; i < n; i++) {
        min_index = -1;
        min_value = INT_MAX;
        for (j = 0; j < NUM_THREADS; j++) {
            if (head_i[j] < (j == NUM_THREADS - 1 ? head_i[j + 1] : n) && tmp_array[head_i[j]] < min_value) {
                min_index = j;
                min_value = tmp_array[head_i[j]];
            }
        }
        array[i] = min_value;
        head_i[min_index]++;
    }

    free(tmp_array);
    free(head_i);
}

void fill_array(int *array, int n) {
    int i;
    
    srand(time(NULL));
    for(i=0; i < n; i++) {
        array[i] = rand()%n;
    }
}
