#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

double F(double x) {
    return 4.0 / (1.0 + x * x);
}

int main(int argc, char *argv[]) {
    int N = atoi(argv[1]);
    int N_threads = omp_get_max_threads();
    double sum[N_threads];
    double delta_x = 1.0 / N;
    double start = omp_get_wtime();
    
    int iter_per_thread = N / N_threads;
    #pragma omp parallel
    {
        int thread_id = omp_get_thread_num();
        int start = thread_id * iter_per_thread;
        
        int end = (thread_id == N_threads - 1) ? N : start + iter_per_thread;
        double x;        
        
        for (int i = start; i < end; i++) {
            x = (i + 0.5) * delta_x;
            sum[thread_id] += F(x);
        }
        
    }
    double sum_total = 0.0;
    for (int i = 0; i < N_threads; i++) {
        sum_total += sum[i];
    }

    double pi = sum_total * delta_x;
    double end = omp_get_wtime();
    double runtime = end - start;

    printf("Pi with %i steps is %.15lf in %lf seconds\n", N, pi, runtime);

    return 0;
}