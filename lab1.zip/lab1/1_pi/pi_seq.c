#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

double F(double x) {
    return 4.0 / (1.0 + x * x);
}

int main(int argc, char *argv[]) {
    int N = atoi(argv[1]);
    double sum = 0.0;
    double delta_x = 1.0 / N;
    double start = omp_get_wtime();
    double x;

    for (int i = 0; i < N; i++) {
        x = (i + 0.5) * delta_x;
        sum += F(x);
    }

    double pi = sum * delta_x;
    double end = omp_get_wtime();
    double runtime = end - start;

    printf("Pi with %i steps is %.15lf in %lf seconds\n", N, pi, runtime);

    return 0;
}